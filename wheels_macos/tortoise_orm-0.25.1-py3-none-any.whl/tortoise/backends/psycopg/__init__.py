from .client import PsycopgClient

client_class = PsycopgClient
